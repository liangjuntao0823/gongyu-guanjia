#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
公寓管家 · 云端一键部署脚本（给房东用）
======================================
作用：把「云端后台 + 获客统计」部署到你自己的腾讯云云函数，生成你自己的后台网址。

前提（先做，见同目录 README.html 图文说明）：
  1) 已注册腾讯云并开通「云函数 SCF」；
  2) 已创建对象存储桶（COS），记住桶名和地域；
  3) 已在控制台创建名为 gongyu-stats 的 Web 函数（Python 3.9，端口 9000，公网访问开放）；
  4) 本机已装 Python 3.8+。

用法：
  1) 用文本编辑器打开本文件，填写下方「请填写」的四项；
  2) 命令行执行：pip install tencentcloud-sdk-python-scf
  3) 命令行执行：python deploy.py
  4) 看到「部署成功」后，把打印出的网址填进 App 设置 → 云端配置 → 云函数地址。
"""
import os, sys, io, base64, zipfile, subprocess, tempfile, shutil, urllib.request

# ================== 请填写 ==================
SECRET_ID  = "填写你的SecretId"
SECRET_KEY = "填写你的SecretKey"
REGION     = "ap-hongkong"                 # 与你的存储桶地域一致
BUCKET     = "填写你的桶名"                  # 例如 fangyuan88-1250000000
PASSWORD   = "88888888"                    # 你的后台口令（App 设置里也会用到）
FUNC_NAME  = "gongyu-stats"
# ===========================================

HERE = os.path.dirname(os.path.abspath(__file__))

def die(msg):
    print("[错误]", msg)
    sys.exit(1)

def main():
    # 1) 校验填写
    for name, v in (("SECRET_ID", SECRET_ID), ("SECRET_KEY", SECRET_KEY), ("BUCKET", BUCKET)):
        if "填写" in v or not v.strip():
            die("请先填写 deploy.py 顶部的账号信息（打开本文件编辑保存即可）。")
    print("正在检查依赖…")

    # 2) 确保 SCF SDK
    try:
        import tencentcloud  # noqa
    except Exception:
        die("缺少 tencentcloud-sdk-python-scf，请先执行：pip install tencentcloud-sdk-python-scf")

    from tencentcloud.common import credential
    from tencentcloud.common.profile.client_profile import ClientProfile
    from tencentcloud.common.profile.http_profile import HttpProfile
    from tencentcloud.scf.v20180416 import scf_client, models

    # 3) 收集函数依赖（Flask）与代码，打成 zip
    print("正在准备函数代码包…")
    tmp = tempfile.mkdtemp(prefix="gj_deploy_")
    req = ["flask==1.0.2", "jinja2==3.0.1", "werkzeug==0.16.0", "itsdangerous==2.0.1", "markupsafe==2.0.1", "click==8.0.1"]
    dep_dir = os.path.join(tmp, "deps")
    os.makedirs(dep_dir)
    pip = [sys.executable, "-m", "pip", "download", "--no-deps", "-d", dep_dir] + req
    r = subprocess.run(pip, capture_output=True, text=True)
    if r.returncode != 0:
        die("pip 下载依赖失败：\n" + (r.stderr or r.stdout)[-500:])

    code_dir = os.path.join(tmp, "code")
    os.makedirs(code_dir)
    for src, dst in (("app.py", "app.py"), ("admin.html", "admin.html"), ("scf_bootstrap", "scf_bootstrap")):
        p = os.path.join(HERE, src)
        if not os.path.exists(p):
            die("缺少 %s（请确认与 deploy.py 在同一目录）" % src)
        shutil.copy(p, os.path.join(code_dir, dst))
    with open(os.path.join(code_dir, "requirements.txt"), "w", encoding="utf-8") as f:
        f.write("\n".join(req))

    zip_path = os.path.join(tmp, "func.zip")
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for folder in (code_dir, dep_dir):
            for root, _, files in os.walk(folder):
                for fn in files:
                    full = os.path.join(root, fn)
                    rel = os.path.relpath(full, code_dir if folder is code_dir else dep_dir)
                    zf.write(full, rel)
    with open(zip_path, "rb") as f:
        zip_b64 = base64.b64encode(f.read()).decode("ascii")
    print("代码包就绪（%d KB）" % (os.path.getsize(zip_path) // 1024))

    # 4) 连接云函数
    cred = credential.Credential(SECRET_ID, SECRET_KEY)
    hp = HttpProfile(); hp.endpoint = "scf.tencentcloudapi.com"
    cp = ClientProfile(); cp.httpProfile = hp
    client = scf_client.ScfClient(cred, REGION, cp)

    # 5) 检测函数是否存在
    try:
        g = models.GetFunctionRequest(); g.FunctionName = FUNC_NAME
        client.GetFunction(g)
        exists = True
    except Exception as e:
        exists = False
        hint = str(e)
    if not exists:
        die("未找到函数 %s（地域 %s）。请先在腾讯云控制台按 README 图文说明创建 Web 函数（Python 3.9、端口 9000、公网访问开放），再运行本脚本。\n[提示] %s" % (FUNC_NAME, REGION, hint[:200]))

    # 6) 上传代码
    req_code = models.UpdateFunctionCodeRequest()
    req_code.FunctionName = FUNC_NAME; req_code.Handler = "index.main_handler"
    req_code.Code = models.Code(); req_code.Code.ZipFile = zip_b64
    try:
        client.UpdateFunctionCode(req_code)
        print("代码上传成功。等待生效…")
    except Exception as e:
        die("上传代码失败：%s" % str(e)[:300])
    time.sleep(20)

    # 7) 配置环境变量 + 超时 + 内存
    env = models.Environment()
    kv = [("BUCKET", BUCKET), ("REGION", REGION), ("SECRET_ID", SECRET_ID), ("SECRET_KEY", SECRET_KEY), ("PASSWORD", PASSWORD)]
    env.Variables = [{"Key": k, "Value": v} for k, v in kv]
    req_cfg = models.UpdateFunctionConfigurationRequest()
    req_cfg.FunctionName = FUNC_NAME
    req_cfg.Timeout = 30
    req_cfg.MemorySize = 512
    req_cfg.Environment = env
    try:
        client.UpdateFunctionConfiguration(req_cfg)
        print("环境变量已配置。等待生效…")
    except Exception as e:
        die("配置环境变量失败：%s" % str(e)[:300])
    time.sleep(20)

    # 8) 取网址
    url = None
    try:
        rq = models.GetFunctionUrlRequest()
        rq.FunctionName = FUNC_NAME
        rq.Qualifier = "$LATEST"
        resp = client.GetFunctionUrl(rq)
        url = getattr(resp, "Url", None)
    except Exception as e:
        try:
            # 兜底：用控制台地址
            rq2 = models.GetFunctionAddressRequest()
            rq2.FunctionName = FUNC_NAME
            resp2 = client.GetFunctionAddress(rq2)
            url = getattr(resp2, "Url", None)
        except Exception as e2:
            url = None
    if not url:
        url = "请到腾讯云控制台 → 函数 gongyu-stats → 触发管理 查看访问地址"

    print("\n===============================================")
    print("部署成功！")
    print("后台网址（填进 App 设置 → 云端配置 → 云函数地址）：")
    print("  %s/?act=admin" % url)
    print("后台口令：%s" % PASSWORD)
    print("===============================================")

if __name__ == "__main__":
    import time
    main()
