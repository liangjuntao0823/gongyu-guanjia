# -*- coding: utf-8 -*-
"""
云函数 gongyu-stats（腾讯云 SCF Web 函数 · 香港地域 · Flask 版）
功能：
  ?act=track    H5 分享页静默埋点（公开，无需鉴权）：room=房号 & mode=脱敏版/完整版 & ref=来源
  ?act=stats    获客统计聚合（需 ?k=<口令sha256>）
  ?act=shares   分享记录列表（需 ?k=<口令sha256>，读取桶内 h/_share_records.json）
依赖：仅 Flask（Web 函数模板自带）+ 标准库，无其他第三方包。
环境变量：BUCKET / REGION / SECRET_ID / SECRET_KEY / PASSWORD（默认 12345678）
"""
import os
import json
import time
import hmac
import hashlib
import urllib.request
import urllib.parse
import urllib.error
import datetime
import xml.etree.ElementTree as ET

from flask import Flask, request, jsonify

BUCKET = os.environ.get("BUCKET", "")
REGION = os.environ.get("REGION", "ap-hongkong")
SECRET_ID = os.environ.get("SECRET_ID", "")
SECRET_KEY = os.environ.get("SECRET_KEY", "")
PASSWORD = os.environ.get("PASSWORD", "12345678")

COS_HOST = "%s.cos.%s.myqcloud.com" % (BUCKET, REGION)

app = Flask(__name__)


def _sha256_hex(s):
    return hashlib.sha256(s.encode("utf-8")).hexdigest()


def cos_request(method, path, body=None, content_type=None, url_query=None):
    """腾讯云 COS V5 签名请求（GET / PUT 对象 / DELETE / 列桶），返回 (status, bytes)
    url_query：可选字典（GetBucket 列目录用，如 prefix/delimiter/max-keys），会参与签名并拼到 URL。"""
    now = int(time.time())
    key_time = "%d;%d" % (now - 60, now + 3600)
    quoted_path = urllib.parse.quote(path, safe="/")
    # URL query 参数参与签名（COS V5：q-url-param-list）
    param_pairs = []
    if url_query:
        for k in sorted(url_query):
            v = url_query[k]
            if v is None or v == "":
                continue
            param_pairs.append((k, str(v)))
    params_str = "&".join(
        urllib.parse.quote(k, safe="") + "=" + urllib.parse.quote(v, safe="")
        for k, v in param_pairs
    )
    q_url_param_list = ";".join(k for k, v in param_pairs)
    headers = {"host": COS_HOST}
    header_list = ["host"]
    if content_type:
        headers["content-type"] = content_type
        header_list.append("content-type")
    header_list = sorted(header_list)
    headers_str = "&".join(
        k + "=" + urllib.parse.quote(str(headers[k]), safe="") for k in header_list
    )
    sign_key = hmac.new(SECRET_KEY.encode("utf-8"), key_time.encode("utf-8"), hashlib.sha1).hexdigest()
    http_string = "%s\n%s\n%s\n%s\n" % (method.lower(), quoted_path, params_str, headers_str)
    sha1_http = hashlib.sha1(http_string.encode("utf-8")).hexdigest()
    string_to_sign = "sha1\n%s\n%s\n" % (key_time, sha1_http)
    signature = hmac.new(sign_key.encode("utf-8"), string_to_sign.encode("utf-8"), hashlib.sha1).hexdigest()
    auth = ("q-sign-algorithm=sha1&q-ak=%s&q-sign-time=%s&q-key-time=%s"
            "&q-header-list=%s&q-url-param-list=%s&q-signature=%s") % (
        SECRET_ID, key_time, key_time, ";".join(header_list), q_url_param_list, signature)
    url = "https://%s%s" % (COS_HOST, quoted_path)
    if param_pairs:
        url += "?" + urllib.parse.urlencode({k: v for k, v in param_pairs})
    req = urllib.request.Request(url, data=body, method=method.upper())
    req.add_header("Authorization", auth)
    for k in header_list:
        if k == "host":
            continue
        req.add_header(k.title(), headers[k])
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            return resp.status, resp.read()
    except urllib.error.HTTPError as e:
        return e.code, e.read()
    except Exception as e:
        return 0, str(e).encode("utf-8", "ignore")


def do_track(qs):
    """H5 埋点：追加一行到 statistics/<日期>.json（失败静默，不阻塞页面）"""
    room = qs.get("room", "")[:40]
    mode = qs.get("mode", "")[:20]
    ref = qs.get("ref", "")[:200]
    if not room:
        return
    now = datetime.datetime.now()
    date = now.strftime("%Y-%m-%d")
    path = "/statistics/%s.json" % date
    line = json.dumps(
        {"t": now.strftime("%Y-%m-%d %H:%M"), "room": room, "mode": mode, "ref": ref},
        ensure_ascii=False,
    ) + "\n"
    status, data = cos_request("GET", path)
    content = b""
    if status == 200:
        content = data
    elif status == 404:
        content = b""
    else:
        return  # 读失败不阻塞埋点
    new_content = content + line.encode("utf-8")
    if len(new_content) > 8 * 1024 * 1024:
        new_content = new_content[-8 * 1024 * 1024:]
    cos_request("PUT", path, body=new_content, content_type="application/json")


def do_stats():
    """聚合最近 90 天埋点：总数 / 今日 / 按日期 / 按房号 / 按模式 / 最近访问"""
    total = 0
    by_room = {}
    by_mode = {}
    by_date = {}
    recent = []
    now = datetime.datetime.now()
    today_str = now.strftime("%Y-%m-%d")
    for i in range(90):
        d = now - datetime.timedelta(days=i)
        date = d.strftime("%Y-%m-%d")
        path = "/statistics/%s.json" % date
        status, data = cos_request("GET", path)
        if status != 200:
            continue
        text = data.decode("utf-8", "ignore")
        for line in text.splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                ev = json.loads(line)
            except Exception:
                continue
            total += 1
            room = str(ev.get("room", "?"))
            mode = str(ev.get("mode", "?"))
            by_room[room] = by_room.get(room, 0) + 1
            by_mode[mode] = by_mode.get(mode, 0) + 1
            by_date[date] = by_date.get(date, 0) + 1
            if len(recent) < 200:
                recent.append({"t": str(ev.get("t", "")), "room": room, "mode": mode, "ref": str(ev.get("ref", ""))})
    return {
        "ok": True,
        "total": total,
        "today": by_date.get(today_str, 0),
        "byDate": [{"date": k, "count": v} for k, v in sorted(by_date.items(), reverse=True)],
        "byRoom": [{"room": k, "count": v} for k, v in sorted(by_room.items(), key=lambda kv: -kv[1])],
        "byMode": [{"mode": k, "count": v} for k, v in sorted(by_mode.items(), key=lambda kv: -kv[1])],
        "recent": recent,
    }


def do_shares():
    """读取分享记录（App 端写桶 h/_share_records.json）"""
    status, data = cos_request("GET", "/h/_share_records.json")
    if status == 200:
        try:
            records = json.loads(data.decode("utf-8", "ignore"))
            if isinstance(records, list):
                return {"ok": True, "records": records}
        except Exception:
            pass
    return {"ok": True, "records": []}


# ============ v1.17 后台管理扩展（改口令 / 桶只读管理） ============

_ADMIN_PWD_PATH = "/h/_admin_pwd.json"


def _effective_password():
    """优先读取桶内 h/_admin_pwd.json（App 设置页改口令后写入），无则用环境变量 PASSWORD"""
    try:
        status, data = cos_request("GET", _ADMIN_PWD_PATH)
        if status == 200:
            obj = json.loads(data.decode("utf-8", "ignore"))
            pwd = str(obj.get("password", ""))
            if pwd:
                return pwd
    except Exception:
        pass
    return PASSWORD


def do_admin_list(qs):
    """列桶对象（GetBucket）：当前层返回目录 + 文件。prefix 限定的前缀逐级展开。"""
    prefix = qs.get("prefix", "h/")[:200]
    # 去掉 query 里可能存在的 k，避免签名混淆（k 不参与桶前缀）
    status, data = cos_request(
        "GET", "/", url_query={"prefix": prefix, "delimiter": "/", "max-keys": "1000", "encoding-type": "url"}
    )
    if status != 200:
        return {"ok": False, "error": "list fail %s" % status}
    try:
        root = ET.fromstring(data.decode("utf-8", "ignore"))
    except Exception as e:
        return {"ok": False, "error": "xml %s" % e}
    ns = {"c": "http://qcloud.com/cos" if root.tag.startswith("{") else ""}
    # 兼容带命名空间的响应
    def _tag(n):
        return n.split("}")[-1] if "}" in n else n
    dirs, files = [], []
    for child in root:
        name = _tag(child.tag)
        if name == "CommonPrefixes":
            for pre in child:
                if _tag(pre.tag) == "Prefix" and pre.text:
                    # encoding-type=url 时 Prefix 为 URL 编码，解码回原始目录名
                    d = urllib.parse.unquote(pre.text)
                    dirs.append({"name": d, "isDir": True})
        elif name == "Contents":
            key = last = size = date = None
            for c in child:
                cn = _tag(c.tag)
                if cn == "Key":
                    key = c.text
                elif cn == "Size":
                    size = int(c.text or "0")
                elif cn == "LastModified":
                    date = c.text
            if key is not None and not key.endswith("/"):
                # encoding-type=url 时 Key 为 URL 编码，需解码回原始名（中文房号/文件名）
                key = urllib.parse.unquote(key)
                files.append({"key": key, "name": key[len(prefix):] if key.startswith(prefix) else key,
                              "size": size, "date": date, "isDir": False})
    # 目录去重、排序（目录在前）
    seen = set()
    dirs2 = []
    for d in dirs:
        if d["name"] not in seen:
            seen.add(d["name"])
            dirs2.append(d)
    dirs2.sort(key=lambda x: x["name"])
    files.sort(key=lambda x: x["name"])
    return {"ok": True, "prefix": prefix, "dirs": dirs2, "files": files}


def do_admin_del(qs):
    """删除桶内对象（云端后台删除文件；对应 App 房源彻底删除已由 App 直连 COS 处理）"""
    key = qs.get("key", "")[:300]
    if not key or key == "/" or ".." in key:
        return {"ok": False, "error": "key 无效"}
    status, _ = cos_request("DELETE", "/" + key)
    if status in (200, 204):
        return {"ok": True}
    return {"ok": False, "error": "delete fail %s" % status}


def do_admin_get(qs):
    """生成对象临时下载链接（GET 签名 URL）"""
    key = qs.get("key", "")[:300]
    if not key or ".." in key:
        return {"ok": False, "error": "key 无效"}
    now = int(time.time())
    key_time = "%d;%d" % (now - 60, now + 3600)
    quoted_path = urllib.parse.quote("/" + key, safe="/")
    headers = {"host": COS_HOST}
    header_list = sorted(["host"])
    headers_str = "&".join(
        k + "=" + urllib.parse.quote(str(headers[k]), safe="") for k in header_list
    )
    sign_key = hmac.new(SECRET_KEY.encode("utf-8"), key_time.encode("utf-8"), hashlib.sha1).hexdigest()
    http_string = "%s\n%s\n\n%s\n" % ("get", quoted_path, headers_str)
    sha1_http = hashlib.sha1(http_string.encode("utf-8")).hexdigest()
    string_to_sign = "sha1\n%s\n%s\n" % (key_time, sha1_http)
    signature = hmac.new(sign_key.encode("utf-8"), string_to_sign.encode("utf-8"), hashlib.sha1).hexdigest()
    auth = ("q-sign-algorithm=sha1&q-ak=%s&q-sign-time=%s&q-key-time=%s"
            "&q-header-list=%s&q-url-param-list=&q-signature=%s") % (
        SECRET_ID, key_time, key_time, ";".join(header_list), signature)
    url = "https://%s%s?%s" % (COS_HOST, quoted_path, auth)
    return {"ok": True, "url": url}


def do_set_pwd(qs, current):
    """App 设置页改口令后同步：写入桶 h/_admin_pwd.json。校验新口令长度。"""
    new = qs.get("new", "")[:60]
    if len(new) < 6:
        return {"ok": False, "error": "口令至少 6 位"}
    body = json.dumps({"password": new, "updated": datetime.datetime.now().strftime("%Y-%m-%d %H:%M")}).encode("utf-8")
    status, _ = cos_request("PUT", _ADMIN_PWD_PATH, body=body, content_type="application/json")
    if status in (200, 204):
        return {"ok": True}
    return {"ok": False, "error": "同步失败 %s" % status}


def _admin_html(k):
    """返回云端后台网页（admin.html）。带 k（App 免登录）则页面直接使用；否则页面 JS 弹口令门。"""
    html = ""
    try:
        with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "admin.html"), "r", encoding="utf-8") as f:
            html = f.read()
    except Exception:
        pass
    if not html:
        html = "<html><head><meta charset='utf-8'></head><body><h2>公寓管家 · 云端后台</h2><p>admin.html 未随函数打包，请重新部署。</p></body></html>"
    host = request.host if request else ""
    html = html.replace("{{FUNC_BASE}}", ("https://" + host) if host else "")
    html = html.replace("{{K}}", k or "")
    return html, 200, {"Content-Type": "text/html; charset=utf-8", "Access-Control-Allow-Origin": "*"}


def _resp(obj, status=200):
    resp = jsonify(obj)
    resp.headers["Access-Control-Allow-Origin"] = "*"
    resp.headers["Access-Control-Allow-Methods"] = "GET,POST,OPTIONS"
    resp.headers["Access-Control-Allow-Headers"] = "Content-Type"
    return resp, status


@app.route("/", methods=["GET", "POST", "OPTIONS"])
def index():
    if request.method == "OPTIONS":
        return _resp({"ok": True})
    if not BUCKET or not SECRET_ID or not SECRET_KEY:
        return _resp({"ok": False, "error": "函数未配置环境变量 BUCKET/SECRET_ID/SECRET_KEY"}, 500)
    args = request.args
    act = args.get("act", "")
    if act == "track":
        do_track({
            "room": args.get("room", ""),
            "mode": args.get("mode", ""),
            "ref": args.get("ref", ""),
        })
        return _resp({"ok": True})
    if act == "admin":
        # v1.17 需求5：云端后台网页（无需鉴权；页面 JS 依据 ?k= 或 localStorage 决定展示/登录门）
        html, status, headers = _admin_html(args.get("k", ""))
        return html, status, headers
    cur_pwd = _effective_password()  # v1.17 需求6：口令优先读桶 h/_admin_pwd.json，App 改口令后即生效
    k = args.get("k", "")
    if k != _sha256_hex(cur_pwd):
        return _resp({"ok": False, "error": "口令错误"}, 401)
    if act == "stats":
        return _resp(do_stats())
    if act == "shares":
        return _resp(do_shares())
    if act == "adminList":
        return _resp(do_admin_list(args))
    if act == "adminDel":
        return _resp(do_admin_del(args))
    if act == "adminGet":
        return _resp(do_admin_get(args))
    if act == "setPwd":
        return _resp(do_set_pwd(args, cur_pwd))
    return _resp({"ok": False, "error": "unknown act"}, 400)


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", "9000")))
