# -*- coding: utf-8 -*-
"""
云函数 gongyu-stats（腾讯云 SCF Web 函数 · 香港地域 · Flask 版）
功能：
  ?act=track    H5 分享页静默埋点（公开，无需鉴权）：room=房号 & mode=脱敏版/完整版 & ref=来源
  ?act=stats    获客统计聚合（需 ?k=<口令sha256>）
  ?act=shares   分享记录列表（需 ?k=<口令sha256>，读取桶内 h/_share_records.json）
依赖：仅 Flask（Web 函数模板自带）+ 标准库，无其他第三方包。
环境变量：BUCKET / REGION / SECRET_ID / SECRET_KEY / PASSWORD（默认 12345678）
"""
import os
import json
import time
import hmac
import hashlib
import urllib.request
import urllib.parse
import urllib.error
import datetime
import xml.etree.ElementTree as ET

from flask import Flask, request, jsonify

BUCKET = os.environ.get("BUCKET", "")
REGION = os.environ.get("REGION", "ap-hongkong")
SECRET_ID = os.environ.get("SECRET_ID", "")
SECRET_KEY = os.environ.get("SECRET_KEY", "")
PASSWORD = os.environ.get("PASSWORD", "12345678")

COS_HOST = "%s.cos.%s.myqcloud.com" % (BUCKET, REGION)

app = Flask(__name__)


def _sha256_hex(s):
    return hashlib.sha256(s.encode("utf-8")).hexdigest()


def cos_request(method, path, body=None, content_type=None, url_query=None):
    """腾讯云 COS V5 签名请求（GET / PUT 对象 / DELETE / 列桶），返回 (status, bytes)
    url_query：可选字典（GetBucket 列目录用，如 prefix/delimiter/max-keys），会参与签名并拼到 URL。"""
    now = int(time.time())
    key_time = "%d;%d" % (now - 60, now + 3600)
    quoted_path = urllib.parse.quote(path, safe="/")
    # 签名用「原始 path」（中文原样），发送 URL 用 percent-encoded path。
    # 腾讯云 COS 验证端以解码后的请求路径比对签名（官方 SDK CosS3Auth 即如此）；
    # 若签名用编码串，中文路径会 SignatureDoesNotMatch（ASCII 路径两种等价，故早期无感知）。
    # URL query 参数参与签名（COS V5：q-url-param-list）
    param_pairs = []
    if url_query:
        for k in sorted(url_query):
            v = url_query[k]
            if v is None or v == "":
                continue
            param_pairs.append((k, str(v)))
    params_str = "&".join(
        urllib.parse.quote(k, safe="") + "=" + urllib.parse.quote(v, safe="")
        for k, v in param_pairs
    )
    q_url_param_list = ";".join(k for k, v in param_pairs)
    headers = {"host": COS_HOST}
    header_list = ["host"]
    if content_type:
        headers["content-type"] = content_type
        header_list.append("content-type")
    header_list = sorted(header_list)
    headers_str = "&".join(
        k + "=" + urllib.parse.quote(str(headers[k]), safe="") for k in header_list
    )
    sign_key = hmac.new(SECRET_KEY.encode("utf-8"), key_time.encode("utf-8"), hashlib.sha1).hexdigest()
    http_string = "%s\n%s\n%s\n%s\n" % (method.lower(), path, params_str, headers_str)
    sha1_http = hashlib.sha1(http_string.encode("utf-8")).hexdigest()
    string_to_sign = "sha1\n%s\n%s\n" % (key_time, sha1_http)
    signature = hmac.new(sign_key.encode("utf-8"), string_to_sign.encode("utf-8"), hashlib.sha1).hexdigest()
    auth = ("q-sign-algorithm=sha1&q-ak=%s&q-sign-time=%s&q-key-time=%s"
            "&q-header-list=%s&q-url-param-list=%s&q-signature=%s") % (
        SECRET_ID, key_time, key_time, ";".join(header_list), q_url_param_list, signature)
    url = "https://%s%s" % (COS_HOST, quoted_path)
    if param_pairs:
        url += "?" + urllib.parse.urlencode({k: v for k, v in param_pairs})
    req = urllib.request.Request(url, data=body, method=method.upper())
    req.add_header("Authorization", auth)
    for k in header_list:
        if k == "host":
            continue
        req.add_header(k.title(), headers[k])
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            return resp.status, resp.read()
    except urllib.error.HTTPError as e:
        return e.code, e.read()
    except Exception as e:
        return 0, str(e).encode("utf-8", "ignore")


def _now():
    """北京时间（云函数容器默认 UTC，所有埋点/统计/口令时间统一 +8）"""
    return datetime.datetime.utcnow() + datetime.timedelta(hours=8)


_TRACK_DEDUP = {}   # v1.40 B3：服务端 30 秒窗口去重（键 room|mode|ref）


def do_track(qs):
    """H5 埋点：追加一行到 statistics/<日期>.json（失败静默，不阻塞页面）
    v1.40 B3：服务端 30 秒窗口去重——App 端已有 30s 去重，服务端再兜一层（多实例内存不共享，属尽力去重）"""
    room = qs.get("room", "")[:40]
    mode = qs.get("mode", "")[:20]
    ref = qs.get("ref", "")[:200]
    if not room:
        return
    key = "%s|%s|%s" % (room, mode, ref)
    now_ts = time.time()
    last = _TRACK_DEDUP.get(key, 0)
    if now_ts - last < 30:
        return
    _TRACK_DEDUP[key] = now_ts
    now = _now()
    date = now.strftime("%Y-%m-%d")
    path = "/statistics/%s.json" % date
    line = json.dumps(
        {"t": now.strftime("%Y-%m-%d %H:%M"), "room": room, "mode": mode, "ref": ref},
        ensure_ascii=False,
    ) + "\n"
    status, data = cos_request("GET", path)
    content = b""
    if status == 200:
        content = data
    elif status == 404:
        content = b""
    else:
        return  # 读失败不阻塞埋点
    new_content = content + line.encode("utf-8")
    if len(new_content) > 8 * 1024 * 1024:
        new_content = new_content[-8 * 1024 * 1024:]
    cos_request("PUT", path, body=new_content, content_type="application/json")


def do_stats(u=""):
    """聚合最近 90 天埋点：总数 / 今日 / 按日期 / 按房号 / 按模式 / 最近访问。
    v1.19 补全 #12：u 为当前用户名，随结果返回，供后台标题显示（多用户口令）。"""
    total = 0
    by_room = {}
    by_mode = {}
    by_date = {}
    recent = []
    now = _now()
    today_str = now.strftime("%Y-%m-%d")
    for i in range(90):
        d = now - datetime.timedelta(days=i)
        date = d.strftime("%Y-%m-%d")
        path = "/statistics/%s.json" % date
        status, data = cos_request("GET", path)
        if status != 200:
            continue
        text = data.decode("utf-8", "ignore")
        for line in text.splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                ev = json.loads(line)
            except Exception:
                continue
            total += 1
            room = str(ev.get("room", "?"))
            mode = str(ev.get("mode", "?"))
            by_room[room] = by_room.get(room, 0) + 1
            by_mode[mode] = by_mode.get(mode, 0) + 1
            by_date[date] = by_date.get(date, 0) + 1
            if len(recent) < 200:
                recent.append({"t": str(ev.get("t", "")), "room": room, "mode": mode, "ref": str(ev.get("ref", ""))})
    return {
        "ok": True,
        "username": u,
        "total": total,
        "today": by_date.get(today_str, 0),
        "byDate": [{"date": k, "count": v} for k, v in sorted(by_date.items(), reverse=True)],
        "byRoom": [{"room": k, "count": v} for k, v in sorted(by_room.items(), key=lambda kv: -kv[1])],
        "byMode": [{"mode": k, "count": v} for k, v in sorted(by_mode.items(), key=lambda kv: -kv[1])],
        "recent": recent,
    }


def do_shares(qs):
    """读取分享记录（v1.40 第6点：App 端写 users/<用户名>/share_records.json，各用户隔离；
    兼容读旧路径 h/_share_records_<用户名>.json——旧记录仍在桶里时也能看到）"""
    u = qs.get("u", "")
    if not u:
        u = "未设置"
    path = "/users/%s/share_records.json" % u
    status, data = cos_request("GET", path)
    if status != 200:
        # v1.40 兼容：旧版分享记录路径（h/_share_records_<用户名>.json）
        legacy = "/h/_share_records_%s.json" % u
        status, data = cos_request("GET", legacy)
    if status == 200:
        try:
            records = json.loads(data.decode("utf-8", "ignore"))
            if isinstance(records, list):
                return {"ok": True, "records": records}
        except Exception:
            pass
    return {"ok": True, "records": []}


# ============ v1.17 后台管理扩展（改口令 / 桶只读管理） ============

_ADMIN_PWD_PATH = "/h/_admin_pwd.json"


def _effective_password():
    """优先读取桶内 h/_admin_pwd.json（App 设置页改口令后写入），无则用环境变量 PASSWORD"""
    try:
        status, data = cos_request("GET", _ADMIN_PWD_PATH)
        if status == 200:
            obj = json.loads(data.decode("utf-8", "ignore"))
            pwd = str(obj.get("password", ""))
            if pwd:
                return pwd
    except Exception:
        pass
    return PASSWORD


def do_admin_list(qs):
    """列桶对象（GetBucket）：当前层返回目录 + 文件。prefix 限定的前缀逐级展开。"""
    prefix = qs.get("prefix", "h/")[:200]
    # 去掉 query 里可能存在的 k，避免签名混淆（k 不参与桶前缀）
    status, data = cos_request(
        "GET", "/", url_query={"prefix": prefix, "delimiter": "/", "max-keys": "1000", "encoding-type": "url"}
    )
    if status != 200:
        return {"ok": False, "error": "list fail %s" % status}
    try:
        root = ET.fromstring(data.decode("utf-8", "ignore"))
    except Exception as e:
        return {"ok": False, "error": "xml %s" % e}
    ns = {"c": "http://qcloud.com/cos" if root.tag.startswith("{") else ""}
    # 兼容带命名空间的响应
    def _tag(n):
        return n.split("}")[-1] if "}" in n else n
    dirs, files = [], []
    for child in root:
        name = _tag(child.tag)
        if name == "CommonPrefixes":
            for pre in child:
                if _tag(pre.tag) == "Prefix" and pre.text:
                    # encoding-type=url 时 Prefix 为 URL 编码，解码回原始目录名
                    d = urllib.parse.unquote(pre.text)
                    dirs.append({"name": d, "isDir": True})
        elif name == "Contents":
            key = last = size = date = None
            for c in child:
                cn = _tag(c.tag)
                if cn == "Key":
                    key = c.text
                elif cn == "Size":
                    size = int(c.text or "0")
                elif cn == "LastModified":
                    date = c.text
            if key is not None and not key.endswith("/"):
                # encoding-type=url 时 Key 为 URL 编码，需解码回原始名（中文房号/文件名）
                key = urllib.parse.unquote(key)
                files.append({"key": key, "name": key[len(prefix):] if key.startswith(prefix) else key,
                              "size": size, "date": date, "isDir": False})
    # 目录去重、排序（目录在前）
    seen = set()
    dirs2 = []
    for d in dirs:
        if d["name"] not in seen:
            seen.add(d["name"])
            dirs2.append(d)
    dirs2.sort(key=lambda x: x["name"])
    # v1.37 需求3：点进房源文件夹（h/<房号>/）时自动展开 media/ 里的媒体文件，少点一层
    if prefix.startswith("h/") and prefix != "h/" and prefix.endswith("/") and prefix.count("/") == 2:
        media_prefix = prefix + "media/"
        for key, size in _list_flat(media_prefix):
            name = key[len(prefix):] if key.startswith(prefix) else key
            files.append({"key": key, "name": name, "size": size, "date": "", "isDir": False})
        dirs2 = [d for d in dirs2 if d["name"] != media_prefix]
    files.sort(key=lambda x: x["name"])
    return {"ok": True, "prefix": prefix, "dirs": dirs2, "files": files}


def _list_flat(prefix):
    """递归列出某前缀下的全部对象，返回 [(key, size)]（用量统计 / 清空 / 媒体展开用）"""
    out = []
    marker = None
    while True:
        q = {"prefix": prefix, "max-keys": "1000", "encoding-type": "url"}
        if marker:
            q["marker"] = marker
        status, data = cos_request("GET", "/", url_query=q)
        if status != 200:
            break
        try:
            root = ET.fromstring(data.decode("utf-8", "ignore"))
        except Exception:
            break
        def _t(n):
            return n.split("}")[-1] if "}" in n else n
        for child in root:
            if _t(child.tag) == "Contents":
                key = size = None
                for c in child:
                    cn = _t(c.tag)
                    if cn == "Key":
                        key = c.text
                    elif cn == "Size":
                        size = int(c.text or "0")
                if key and not key.endswith("/"):
                    out.append((urllib.parse.unquote(key), size))
        truncated = False
        nm = None
        for child in root:
            if _t(child.tag) == "IsTruncated":
                truncated = (child.text == "true")
            elif _t(child.tag) == "NextMarker":
                nm = child.text
        if not truncated or not nm:
            break
        marker = nm
    return out


def do_admin_del(qs):
    """删除桶内对象（云端后台删除文件；对应 App 房源彻底删除已由 App 直连 COS 处理）"""
    key = qs.get("key", "")[:300]
    if not key or key == "/" or ".." in key:
        return {"ok": False, "error": "key 无效"}
    status, _ = cos_request("DELETE", "/" + key)
    if status in (200, 204):
        _ops_append("删除桶文件", "", qs.get("uname", "")[:20], key)
        return {"ok": True}
    return {"ok": False, "error": "delete fail %s" % status}


# ============ v1.37 桶储存用量 / 清空统计 / 云端操作记录 ============

def _usage_cat(key):
    """按前缀归类对象用途（用量分项）v1.40：新增 users/<用户名>/ 用户私有目录归类"""
    if key.startswith("statistics/"):
        return "访问统计"
    if "/media/" in key or key.startswith("users/") and "/media/" in key:
        return "房源媒体"
    if key.startswith("h/"):
        return "房源与分享数据"
    if key.startswith("users/"):
        # 用户私有目录：backups=云端备份；shares=分享页；share_records=分享记录；其余归用户数据
        rest = key[len("users/"):]
        sub = rest.split("/", 1)
        if len(sub) == 2:
            if sub[1].startswith("backups/"):
                return "云端备份"
            if sub[1].startswith("shares/"):
                return "房源与分享数据"
        return "用户数据"
    if key.startswith("backup") or key.startswith("backups/") or "/backup/" in key:
        return "云端备份"
    return "其他"


def do_admin_usage():
    """桶储存空间用量：遍历全部对象，总大小 + 按用途分项"""
    items = _list_flat("")
    total = 0
    parts = {}
    for key, size in items:
        total += size
        c = _usage_cat(key)
        parts[c] = parts.get(c, 0) + size
    return {"ok": True, "total": total, "total_files": len(items),
            "parts": [{"name": k, "size": v} for k, v in parts.items()]}


def do_clear_stats():
    """清空访问统计：删除桶 statistics/ 下全部埋点文件（清除 test101 等测试记录）"""
    items = _list_flat("statistics/")
    deleted = 0
    for key, _ in items:
        st, _ = cos_request("DELETE", "/" + key)
        if st in (200, 204):
            deleted += 1
    _ops_append("清空访问统计", "", "", "删除 %d 个统计文件" % deleted)
    return {"ok": True, "deleted": deleted}


_OPS_PATH = "/h/_ops.json"
_OPS_MAX = 300


def _ops_append(op, room, uname, detail):
    """追加一条云端操作记录（带用户名 + 北京时间）。读-改-写，低频场景可接受并发覆盖。"""
    try:
        st, data = cos_request("GET", _OPS_PATH)
        lst = []
        if st == 200:
            try:
                lst = json.loads(data.decode("utf-8", "ignore"))
            except Exception:
                lst = []
        if not isinstance(lst, list):
            lst = []
        lst.insert(0, {"t": _now().strftime("%Y-%m-%d %H:%M"), "op": op, "room": room, "user": uname, "detail": detail})
        lst = lst[:_OPS_MAX]
        cos_request("PUT", _OPS_PATH, body=json.dumps(lst, ensure_ascii=False).encode("utf-8"), content_type="application/json")
    except Exception:
        pass


def do_log_op(qs):
    """App 本机发起云端操作时写一条云端操作记录（带当前用户名）"""
    op = qs.get("op", "")[:40]
    room = qs.get("room", "")[:40]
    uname = qs.get("uname", "")[:20]
    detail = qs.get("detail", "")[:300]
    if not op:
        return {"ok": False, "error": "op 为空"}
    _ops_append(op, room, uname, detail)
    return {"ok": True}


def do_ops(qs):
    """读取云端操作记录（操作日志云端区显示，每条带用户名）"""
    st, data = cos_request("GET", _OPS_PATH)
    if st == 200:
        try:
            lst = json.loads(data.decode("utf-8", "ignore"))
            if isinstance(lst, list):
                return {"ok": True, "records": lst}
        except Exception:
            pass
    return {"ok": True, "records": []}


def do_del_op(qs):
    """删除一条云端操作记录（App 操作日志云端区左滑/多选删除）"""
    t = qs.get("t", ""); op = qs.get("op", ""); room = qs.get("room", "")
    user = qs.get("user", ""); detail = qs.get("detail", "")
    st, data = cos_request("GET", _OPS_PATH)
    lst = []
    if st == 200:
        try:
            lst = json.loads(data.decode("utf-8", "ignore"))
        except Exception:
            lst = []
    if not isinstance(lst, list):
        lst = []
    found = False
    new = []
    for x in lst:
        if (not found and x.get("t") == t and x.get("op") == op and x.get("room") == room
                and x.get("user") == user and x.get("detail") == detail):
            found = True
            continue
        new.append(x)
    cos_request("PUT", _OPS_PATH, body=json.dumps(new, ensure_ascii=False).encode("utf-8"), content_type="application/json")
    return {"ok": True, "deleted": 1 if found else 0}


def do_admin_get(qs):
    """生成对象临时下载链接（GET 签名 URL）"""
    key = qs.get("key", "")[:300]
    if not key or ".." in key:
        return {"ok": False, "error": "key 无效"}
    now = int(time.time())
    key_time = "%d;%d" % (now - 60, now + 3600)
    quoted_path = urllib.parse.quote("/" + key, safe="/")
    headers = {"host": COS_HOST}
    header_list = sorted(["host"])
    headers_str = "&".join(
        k + "=" + urllib.parse.quote(str(headers[k]), safe="") for k in header_list
    )
    sign_key = hmac.new(SECRET_KEY.encode("utf-8"), key_time.encode("utf-8"), hashlib.sha1).hexdigest()
    http_string = "%s\n%s\n\n%s\n" % ("get", quoted_path, headers_str)
    sha1_http = hashlib.sha1(http_string.encode("utf-8")).hexdigest()
    string_to_sign = "sha1\n%s\n%s\n" % (key_time, sha1_http)
    signature = hmac.new(sign_key.encode("utf-8"), string_to_sign.encode("utf-8"), hashlib.sha1).hexdigest()
    auth = ("q-sign-algorithm=sha1&q-ak=%s&q-sign-time=%s&q-key-time=%s"
            "&q-header-list=%s&q-url-param-list=&q-signature=%s") % (
        SECRET_ID, key_time, key_time, ";".join(header_list), signature)
    url = "https://%s%s?%s" % (COS_HOST, quoted_path, auth)
    return {"ok": True, "url": url}


def do_set_pwd(qs, current):
    """App 设置页改口令后同步：写入桶 h/_admin_pwd.json。校验新口令长度。"""
    new = qs.get("new", "")[:60]
    if len(new) < 6:
        return {"ok": False, "error": "口令至少 6 位"}
    body = json.dumps({"password": new, "updated": _now().strftime("%Y-%m-%d %H:%M")}).encode("utf-8")
    status, _ = cos_request("PUT", _ADMIN_PWD_PATH, body=body, content_type="application/json")
    if status in (200, 204):
        return {"ok": True}
    return {"ok": False, "error": "同步失败 %s" % status}


def _admin_html(k, u=""):
    """返回云端后台网页（admin.html）。带 k（App 免登录）则页面直接使用；否则页面 JS 弹口令门。
    v1.19 补全 #12：u 为当前用户名（多用户口令，页面标题区显示当前用户）。"""
    html = ""
    try:
        with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "admin.html"), "r", encoding="utf-8") as f:
            html = f.read()
    except Exception:
        pass
    if not html:
        html = "<html><head><meta charset='utf-8'></head><body><h2>公寓管家 · 云端后台</h2><p>admin.html 未随函数打包，请重新部署。</p></body></html>"
    host = request.host if request else ""
    html = html.replace("{{FUNC_BASE}}", ("https://" + host) if host else "")
    html = html.replace("{{K}}", k or "")
    html = html.replace("{{U}}", u or "")
    # v1.37：禁止缓存，保证浏览器/App 每次拿到最新后台页（此前用户看到旧版是缓存导致）
    return html, 200, {"Content-Type": "text/html; charset=utf-8", "Access-Control-Allow-Origin": "*", "Cache-Control": "no-store, no-cache, must-revalidate", "Pragma": "no-cache", "Expires": "0"}


def _resp(obj, status=200):
    resp = jsonify(obj)
    resp.headers["Access-Control-Allow-Origin"] = "*"
    resp.headers["Access-Control-Allow-Methods"] = "GET,POST,OPTIONS"
    resp.headers["Access-Control-Allow-Headers"] = "Content-Type"
    return resp, status


@app.route("/", methods=["GET", "POST", "OPTIONS"])
def index():
    if request.method == "OPTIONS":
        return _resp({"ok": True})
    if not BUCKET or not SECRET_ID or not SECRET_KEY:
        return _resp({"ok": False, "error": "函数未配置环境变量 BUCKET/SECRET_ID/SECRET_KEY"}, 500)
    args = request.args
    act = args.get("act", "")
    if act == "track":
        do_track({
            "room": args.get("room", ""),
            "mode": args.get("mode", ""),
            "ref": args.get("ref", ""),
        })
        return _resp({"ok": True})
    if act == "admin":
        # v1.17 需求5：云端后台网页（无需鉴权；页面 JS 依据 ?k= 或 localStorage 决定展示/登录门）
        # v1.19 补全 #12：多用户口令，u 为当前用户名（App 免登录 URL 带 &u=）
        html, status, headers = _admin_html(args.get("k", ""), args.get("u", ""))
        return html, status, headers
    cur_pwd = _effective_password()  # v1.17 需求6：口令优先读桶 h/_admin_pwd.json，App 改口令后即生效
    k = args.get("k", "")
    if k != _sha256_hex(cur_pwd):
        return _resp({"ok": False, "error": "口令错误"}, 401)
    if act == "stats":
        return _resp(do_stats(args.get("u", "")))
    if act == "shares":
        return _resp(do_shares(args))
    if act == "adminList":
        return _resp(do_admin_list(args))
    if act == "adminDel":
        return _resp(do_admin_del(args))
    if act == "adminGet":
        return _resp(do_admin_get(args))
    if act == "setPwd":
        return _resp(do_set_pwd(args, cur_pwd))
    if act == "usage":
        return _resp(do_admin_usage())
    if act == "clearStats":
        return _resp(do_clear_stats())
    if act == "ops":
        return _resp(do_ops(args))
    if act == "logOp":
        return _resp(do_log_op(args))
    if act == "delOp":
        return _resp(do_del_op(args))
    return _resp({"ok": False, "error": "unknown act"}, 400)


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", "9000")))
